# README - Proyecto Web Forza Gym

## Descripción del proyecto

Forza Gym es un sitio web multipágina para un gimnasio ubicado en Buenos Aires.
El objetivo es mostrar la información principal del gimnasio de forma clara y navegable.

## Secciones

- Inicio: presentación general, llamado a la acción y accesos a secciones.
- Actividades: disciplinas disponibles y grilla semanal de horarios.
- Planes: precios y beneficios de cada plan.
- Nosotros: historia del gimnasio, datos principales y equipo.
- Contacto: formulario HTML de consulta y datos de contacto.

## Tecnologías utilizadas

- HTML5
- CSS3
- Flexbox
- Media queries
- JavaScript
- jQuery

## JavaScript agregado

En `contacto.html` se agregó una calculadora de plan usando contenidos vistos después del primer parcial:

- Variables con `let`
- Funciones
- Eventos con `addEventListener`
- Eventos `click`, `dblclick`, `mouseover` y `mouseout`
- Condicionales `if`, `else if`, `else`
- Ciclo `for`
- Ciclo `while`
- Lectura de datos con `getElementById`
- Mensajes con `alert`
- Resultado en pantalla con `innerHTML`

Funciones agregadas:

- `calcularPlan()`: valida datos, calcula precio y aplica descuento.
- `obtenerPrecio()`: devuelve el precio según la actividad.
- `mostrarResultado()`: muestra el mensaje final en pantalla.
- `mostrarCuotas()`: usa `while` para mostrar opciones de pago.
- `generarRutina()`: usa `for` para armar una rutina semanal.
- `borrarRutina()` y `limpiarFormulario()`: limpian datos ingresados.

## jQuery agregado

Se agregó `jquery-4.0.0.min.js` en la misma carpeta del proyecto y un archivo `script-jquery.js`.

Contenidos usados del material:

- `$(document).ready(function(){ ... })`
- Selector por id: `$("#id")`
- Selector por clase: `$(".clase")`
- Evento `click`
- Eventos `focus` y `blur`
- Efectos `hide()` y `show()`

Funciones agregadas con jQuery:

- Ocultar y mostrar la grilla de horarios.
- Ocultar y mostrar los datos de contacto.
- Mostrar ayuda cuando el usuario completa campos del formulario.

## Estructura del proyecto

```text
tp-gym
├── assets
│   └── logo.svg
├── index.html
├── actividades.html
├── planes.html
├── nosotros.html
├── contacto.html
├── jquery-4.0.0.min.js
├── script.js
├── script-jquery.js
├── styles.css
├── Proyecto_ForzaGym.pdf
└── README.md
```

## Aclaración

El CSS original se mantiene. La reorganización se hizo separando el contenido en
páginas HTML y reutilizando las clases existentes.

## Cómo ver el proyecto

Abrir `index.html` en el navegador y navegar por las páginas desde el menú superior.
