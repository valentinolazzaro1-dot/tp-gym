let botonCalcular = document.getElementById("btn-calcular");
let botonLimpiar = document.getElementById("btn-limpiar");
let botonRutina = document.getElementById("btn-rutina");
let botonBorrarRutina = document.getElementById("btn-borrar-rutina");

if (botonCalcular != null) {
    botonCalcular.addEventListener("click", calcularPlan);
    botonCalcular.addEventListener("mouseover", marcarBoton);
    botonCalcular.addEventListener("mouseout", desmarcarBoton);
}

if (botonLimpiar != null) {
    botonLimpiar.addEventListener("click", limpiarFormulario);
}

if (botonRutina != null) {
    botonRutina.addEventListener("click", generarRutina);
    botonRutina.addEventListener("dblclick", borrarRutina);
}

if (botonBorrarRutina != null) {
    botonBorrarRutina.addEventListener("click", borrarRutina);
}

function calcularPlan() {
    let nombre = document.getElementById("nombre").value;
    let edad = document.getElementById("edad").value;
    let actividad = document.getElementById("actividad").value;
    let codigo = document.getElementById("codigo").value;
    let precioPlan;

    if (nombre == "" || edad == "" || actividad == "") {
        alert("Por favor, ingresá tu nombre, tu edad y elegí una actividad.");
    } else if (edad < 13) {
        alert("Lo sentimos, debés ser mayor de 13 años para inscribirte en el gimnasio.");
    } else {
        precioPlan = obtenerPrecio(actividad);

        if (codigo == "PROMO20") {
            precioPlan = precioPlan - (precioPlan * 0.20);
            alert("Código PROMO20 aplicado. Tenés un 20% de descuento en tu primer mes.");
        }

        mostrarResultado(nombre, actividad, precioPlan);
        mostrarCuotas(precioPlan);
    }
}

function obtenerPrecio(actividad) {
    let precio;

    if (actividad == "musculacion") {
        precio = 38000;
    } else if (actividad == "todas") {
        precio = 45000;
    } else {
        precio = 30000;
    }

    return precio;
}

function mostrarResultado(nombre, actividad, precioPlan) {
    let mensajeFinal = "Hola " + nombre + ". El valor de tu plan es de $" + precioPlan + ".";
    let mensajeActividad = "";

    if (actividad == "musculacion") {
        mensajeActividad = "Incluye acceso libre a la sala de musculación.";
    } else if (actividad == "todas") {
        mensajeActividad = "Incluye musculación y todas las clases grupales.";
    } else {
        mensajeActividad = "Incluye clases grupales de la actividad elegida.";
    }

    document.getElementById("resultado").innerHTML = mensajeFinal + "<br>" + mensajeActividad;
}

function mostrarCuotas(precioPlan) {
    let cuotas = 1;
    let mensaje = "<h4>Opciones de pago</h4>";

    while (cuotas <= 3) {
        mensaje = mensaje + cuotas + " cuota(s) de $" + (precioPlan / cuotas) + "<br>";
        cuotas++;
    }

    document.getElementById("cuotas").innerHTML = mensaje;
}

function generarRutina() {
    let dias = document.getElementById("dias-rutina").value;
    let actividad = document.getElementById("actividad-rutina").value;
    let mensaje = "<h4>Rutina sugerida</h4>";

    if (dias == "" || actividad == "") {
        alert("Ingresá la cantidad de días y elegí una actividad.");
    } else if (dias < 1) {
        alert("La cantidad de días debe ser mayor a cero.");
    } else if (dias > 6) {
        alert("Te recomendamos dejar al menos un día de descanso.");
    } else {
        for (let dia = 1; dia <= dias; dia++) {
            mensaje = mensaje + "Día " + dia + ": " + actividad + "<br>";
        }

        document.getElementById("resultado-rutina").innerHTML = mensaje;
    }
}

function borrarRutina() {
    document.getElementById("dias-rutina").value = "";
    document.getElementById("actividad-rutina").value = "";
    document.getElementById("resultado-rutina").innerHTML = "";
}

function marcarBoton() {
    document.getElementById("resultado").innerHTML = "Completá los datos y calculá tu plan.";
}

function desmarcarBoton() {
    if (document.getElementById("resultado").innerHTML == "Completá los datos y calculá tu plan.") {
        document.getElementById("resultado").innerHTML = "";
    }
}

function limpiarFormulario() {
    document.getElementById("nombre").value = "";
    document.getElementById("edad").value = "";
    document.getElementById("actividad").value = "";
    document.getElementById("codigo").value = "";
    document.getElementById("email").value = "";
    document.getElementById("telefono").value = "";
    document.getElementById("mensaje").value = "";
    document.getElementById("resultado").innerHTML = "";
    document.getElementById("cuotas").innerHTML = "";
}
