$(document).ready(function(){
    $("#ayuda-jquery").hide();

    $("#btn-ocultar-horarios").click(function(){
        $(".schedule-wrapper").hide();
    });

    $("#btn-mostrar-horarios").click(function(){
        $(".schedule-wrapper").show();
    });

    $("#btn-ocultar-contacto").click(function(){
        $(".contact-data").hide();
    });

    $("#btn-mostrar-contacto").click(function(){
        $(".contact-data").show();
    });

    $("input").focus(function(){
        $("#ayuda-jquery").show();
    });

    $("input").blur(function(){
        $("#ayuda-jquery").hide();
    });
});
